<?php

namespace App\Widgets;

/**
 * Navigation Menu widget class
 *
 * @since 3.0.0
 */
 class Blog extends \WP_Widget
 {
 	private $excerpt_length;

 	private $readmore_text;

 	public function __construct()
 	{
 		$widget_ops = [
 			'classname' => 'blog_widget',
 			'description' => __('Add a blog content to your website.')
 		];
 		parent::__construct('blog_widget', __('JB Blog Content'), $widget_ops);
 	}

 	public function widget($args, $instance)
 	{
 		/** This filter is documented in wp-includes/default-widgets.php */
 		$instance['title'] = apply_filters('widget_title', empty($instance['title']) ? '' : $instance['title'], $instance, $this->id_base);
 		$instance['number'] = !empty($instance['number']) ? absint($instance['number']) : 5;

 		$instace['excerpt_length'] = isset($instace['excerpt_length']) ? absint($instance['excerpt_length']) : -1;
 		$instance['readmore_text'] = isset($instance['readmore_text']) ? esc_attr($instance['readmore_text']) : esc_attr('Read More');

 		echo $args['before_widget'];

 		$query_args = [
 			'post_type' => 'post',
 			'post_status' => 'publish',
 			'posts_per_page' => $instance['number']
 		];
 		$query = new \WP_Query($query_args);

 		echo \App\template('widgets.blog_render', [
 			'query' => $query,
 			'title' => $instance['title'],
 			'args' => $args
 		]);

 		echo $args['after_widget'];
 	}

 	public function update($new_instance, $old_instance)
 	{
 		$instance['title'] = strip_tags(stripslashes($new_instance['title']));
 		$instance['number'] = (int) $new_instance['number'];
 		$instance['excerpt_length'] = (int) $new_instance['excerpt_length'];
 		$instance['readmore_text'] = strip_tags(stripslashes($new_instance['readmore_text']));

 		$this->$excerpt_length = $instance['excerpt_length'];
 		add_filter('excerpt_length', [$this, 'custom_excerpt_length'], 999);

 		$this->$readmore_text = $instance['readmore_text'];
 		add_filter('the_content_more_link', [$this, 'custom_readmore_link'], 999);

 		return $instance;
 	}

 	public function form($instance)
 	{
 		$title = isset($instance['title']) ? esc_attr($instance['title']) : esc_attr('');
 		$number = isset($instance['number']) ? absint($instance['number']) : 5;
 		$excerpt_length = isset($instance['excerpt_length']) ? absint($instance['excerpt_length']) : 55;
 		$readmore_text = isset($instance['readmore_text']) ? esc_attr($instance['readmore_text']) : esc_attr('Read More');

 		echo \App\template('widgets.blog_form', [
 			'title' => [
 				'val' => $title,
 				'id' => $this->get_field_id('title'),
 				'name' => $this->get_field_name('title')
 			],
 			'number' => [
 				'val' => $number,
 				'id' => $this->get_field_id('number'),
 				'name' => $this->get_field_name('number')
 			],
 			'excerpt_length' => [
 				'val' => $excerpt_length,
 				'id' => $this->get_field_id('excerpt_length'),
 				'name' => $this->get_field_name('excerpt_length')
 			],
 			'readmore_text' => [
 				'val' => $readmore_text,
 				'id' => $this->get_field_id('readmore_text'),
 				'name' => $this->get_field_name('readmore_text')
 			],
 		]);
 	}

 	//limiting excertp length to 10 words

 	public function custom_excerpt_length($length)
 	{
 		$length = isset($this->$excerpt_length) ? $this->$excerpt_length : 55;

 		return $length;
 	}

 	public function custom_readmore_link()
 	{
 		return '<a class="more-link" href="' . get_permalink() . '">' . $this->$readmore_text . '</a>';
 	}
 }
