@while ($query->have_posts())
@php
$query->the_post();
@endphp

<div class="post-item">
    <h3> @php the_title() @endphp </h3>
    @if(has_post_thumbnail())
    <p>@php the_post_thumbnail() @endphp</p>
    @endif
    <p>@php the_excerpt(); @endphp</p>
</div>
@endwhile